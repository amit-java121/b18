package com;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Test {
	
	public static void main(String[] args) {
		
		Payment payment = new Payment();
		payment.setCardNumber(1888888881);
		payment.setCvv(123);
		payment.setUserId(101010);
		payment.setUserName("Xpert it");
		
		try {
		FileOutputStream fos = new FileOutputStream("C:\\Users\\Amit\\Desktop\\test.txt");
		
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		oos.writeObject(payment);
		oos.close();
		
		}catch(Exception e) {
			e.printStackTrace();
		}
//		
//		try {
//		FileInputStream fis = new FileInputStream("C:\\Users\\Amit\\Desktop\\test.txt");
//		ObjectInputStream ois = new ObjectInputStream(fis);
//		
//		Payment payment = (Payment)ois.readObject();
//		
//		System.out.println(payment.getCardNumber());
//		System.out.println(payment.getCvv());
//		System.out.println(payment.getUserId());
//		System.out.println(payment.getUserName());
//		
//		ois.close();
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
		
	}

}
