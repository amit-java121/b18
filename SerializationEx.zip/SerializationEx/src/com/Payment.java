package com;

import java.io.Serializable;

public class Payment implements Serializable{

	private static final long serialVersionUID = 813392868710158447L;
	private static int userId;
	private long cardNumber;
	private int cvv;
	private transient String userName;
	
	
	public int getUserId() {
		return userId;
	}
	public long getCardNumber() {
		return cardNumber;
	}
	public int getCvv() {
		return cvv;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	

}
