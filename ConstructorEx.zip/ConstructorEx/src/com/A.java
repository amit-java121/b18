package com;

public class A {
	int a;
	int b;
	public A(){
		//this(50,10);
		System.out.println("default const::");
		
	}
	
	public A(int a){
			System.out.println("paramt const :"+a);
	}


	public A(int aa,int bb){
		this(10);
		a =aa;
		b=bb;
	}
	
	public void calculation() {
		int sum = a+b;
		System.out.println(sum);
	}
	public static void main(String[] args) {
		A a = new A();
		
		a.calculation();
		//A a1 = new A(10);
		//A a2 = new A(10,"Ajay");
	}
}
