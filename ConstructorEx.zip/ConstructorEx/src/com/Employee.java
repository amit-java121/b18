package com;

public class Employee {
	
	int age;
	String name;
	
//	public Employee() {
//		System.out.println("default const:::");
//	}
	
	public Employee(int a,String n) {
		System.out.println("param const:::");
		age =a;
		name= n;
	}
	
	public void print() {
		System.out.println("age: "+age+" name: "+name);
	}
	
	public static void main(String[] args) {
//		Employee emp = new Employee();
//		emp.print();
		
		Employee emp1 = new Employee(25,"xpertit");
		
		emp1.print();
		
	}
	
}

