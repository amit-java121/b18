package com;

public class TestCustomer {
	
	public static void main(String[] args) {
		//Customer customer = new Customer(100, 17181881, "Ajay", "ajay@gmail.com");
		
		Customer customer1 = new Customer(181881880, "ajay@gmail.com");
		
	}

}
