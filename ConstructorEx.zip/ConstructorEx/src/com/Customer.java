package com;

public class Customer {
	int customerId;
	int addharNumber;
	String customerName;
	String customerEmailId;
	
//	public Customer(int customerId, int addharNumber, String customerName, String customerEmailId) {
//		super();
//		this.customerId = customerId;
//		this.addharNumber = addharNumber;
//		this.customerName = customerName;
//		this.customerEmailId = customerEmailId;
//	}
	
	
	public Customer(int addharNumber,String customerEmailId) {
		this.addharNumber = addharNumber;
		this.customerEmailId = customerEmailId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public int getAddharNumber() {
		return addharNumber;
	}

	public void setAddharNumber(int addharNumber) {
		this.addharNumber = addharNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerEmailId() {
		return customerEmailId;
	}

	public void setCustomerEmailId(String customerEmailId) {
		this.customerEmailId = customerEmailId;
	}
	

}
