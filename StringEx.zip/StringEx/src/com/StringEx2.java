package com;

public class StringEx2 {
	
	public static void main(String[] args) {
		
		String str = "hello";
		String str1 = "my,name,is,this,my";

	//	System.out.println(str.contains("el"));
		//System.out.println(str.contentEquals("hello"));
		//System.out.println(str.endsWith("o"));
		//System.out.println(str.indexOf('o'));
		//System.out.println(str.isBlank());
		//System.out.println(str.isEmpty());
		
		//String str2 = str.replace("hello", "hi");
		//System.out.println(str2);
		//System.out.println(str.length());
		//System.out.println(str.substring(2, 4));
		
//		String[] strArray = str1.split(",");
//		
//		for(int i=0; i<strArray.length; i++) {
//			
//			System.out.println(strArray[i]);
//		}
		
//		for(String arr:strArray) {
//			System.out.println(arr);
//		}
		
		//System.out.println(str1.toUpperCase());
		//System.out.println(str1.toLowerCase());
		
		//System.out.println(str.charAt(2));
		String s ="hello";
		String s1 = " hello ";
		
		System.out.println(s.equals(s1.trim()));
		
		//System.out.println(str.trim());
		
		String num ="1231414";
		
		//long cNum = Long.valueOf(num);
		
		//System.out.println(cNum);
		
		
	}

}
