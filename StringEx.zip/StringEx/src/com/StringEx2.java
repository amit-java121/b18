package com;

public class StringEx2 {
	
	public static void main(String[] args) {
		
		String str = "hello";

	//	System.out.println(str.contains("el"));
		//System.out.println(str.contentEquals("hello"));
		//System.out.println(str.endsWith("o"));
		//System.out.println(str.indexOf('o'));
		//System.out.println(str.isBlank());
		//System.out.println(str.isEmpty());
		
		//String str2 = str.replace("hello", "hi");
		//System.out.println(str2);
		//System.out.println(str.length());
		System.out.println(str.substring(2, 4));
		
	}

}
