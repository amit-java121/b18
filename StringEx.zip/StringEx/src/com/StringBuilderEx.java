package com;

public class StringBuilderEx {
	
	public static void main(String[] args) {
		StringBuilder sbb = new StringBuilder("");
		
	}

}
