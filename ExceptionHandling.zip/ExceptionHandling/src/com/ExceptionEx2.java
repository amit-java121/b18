package com;

public class ExceptionEx2 {
	
public void devesion(int a,int b,String name) {
		
		System.out.println("before devision");
		
		try {
			
			try {
			if(name.equals("ajay")) {
				System.out.println("inside if ::");
			}
			}catch(NullPointerException npe) {
				System.out.println("null pointer catch executed::");
				System.out.println(npe.getMessage());
			}
			
			int div = a/b;
			System.out.println(div);
		
		}
		catch(ArithmeticException ae) {
			System.out.println("catch block executed::");
			System.out.println(ae.getMessage());
			ae.printStackTrace();
		}
		
		System.out.println("after devision:::");
		try {
		int sum = a+b;
		System.out.println("sum: "+sum);
		}catch(ArithmeticException ae) {
			ae.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) {
		ExceptionEx2 ee = new ExceptionEx2();
		 ee.devesion(10, 0,null);
	}


}
