package com;


public class UnCheckedEx {
	
	public void test()  throws Exception{
		
		int div = 10/0;
		
		System.out.println("after devision:::");
		
	}
	
	
	
	public static void main(String[] args) {
		UnCheckedEx ce = new UnCheckedEx();
		try {
		
			ce.test();
		
		}catch(Exception e) {
			System.out.println("Arithmatic exception handled::");
		}
	}

}
