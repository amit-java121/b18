package com;

public class ExceptionEx5 {
	
public void devesion(int a,int b,String name) {
		
		System.out.println("before devision");
		
		try {
			
	 /// Db 
			if(name.equals("ajay")) {
				System.out.println("inside if ::");
			}
			
			int div = a/b;
			System.out.println(div);
			//db connection close
		
		}finally {
			//db connection close here
			System.out.println("finally block executed::");
			
		}
		
		System.out.println("after finally block:::");
		
		
	}
	
	
	public static void main(String[] args) {
		ExceptionEx5 ee = new ExceptionEx5();
		 ee.devesion(10, 2,null);
	}


}
