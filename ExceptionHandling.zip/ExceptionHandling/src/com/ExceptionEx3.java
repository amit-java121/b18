package com;

public class ExceptionEx3 {
	
public void devesion(int a,int b,String name) {
		
		System.out.println("before devision");
		
		try {
			
	
			if(name.equals("ajay")) {
				System.out.println("inside if ::");
			}
			
			int div = a/b;
			System.out.println(div);
		
		}
		catch(ArithmeticException ae) {
		
			System.out.println("You can not devide by zero please try another number::");
		
		}catch(NullPointerException npe) {
			System.out.println("Name should not be empty or null");
		}
		catch(Exception e) {
			System.out.println("");
		}
		
		
	}
	
	
	public static void main(String[] args) {
		ExceptionEx3 ee = new ExceptionEx3();
		 ee.devesion(10, 0,null);
	}


}
