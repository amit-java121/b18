package com;

public class ExceptionEx1 {
	
	public void devesion(int a,int b) {
		
		System.out.println("before devision");
		
		try {
			
			int div = a/b;
			System.out.println(div);
		
		}catch(ArithmeticException ae) {
			System.out.println("catch block executed::");
			System.out.println(ae.getMessage());
			ae.printStackTrace();
		}
		
		System.out.println("after devision:::");
		
		int sum = a+b;
		System.out.println("sum: "+sum);
		
	}
	
	
	public static void main(String[] args) {
		ExceptionEx1 ee = new ExceptionEx1();
		 ee.devesion(10, 0);
	}

}
