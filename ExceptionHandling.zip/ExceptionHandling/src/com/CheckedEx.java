package com;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class CheckedEx {
	
	public void test() {
		try {
			
		Class.forName("com.jdbc.cj.mysql.Driver");
		
		}catch(Exception io) {
			
		}
		
	}
	
	public void readDataFromFile() throws FileNotFoundException {
		
		File file = new File("C://test.txt");
		FileOutputStream fos = new FileOutputStream(file);
		
	}
	
	public void writeDataIntoFile() {
		
		try {
			readDataFromFile();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		CheckedEx ce = new CheckedEx();
		ce.test();
		
		ce.writeDataIntoFile();
	}

}
