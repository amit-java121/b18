package com;

public class ExceptionEx4 {
	
public void devesion(int a,int b,String name) {
		
		System.out.println("before devision");
		
		try {
			
	
			if(name.equals("ajay")) {
				System.out.println("inside if ::");
			}
			
			int div = a/b;
			System.out.println(div);
		
		}
		catch(Exception e) {
			System.out.println("catch block executed::");
		}finally {
			System.out.println("finally block executed::");
			
		}
		
		
	}
	
	
	public static void main(String[] args) {
		ExceptionEx4 ee = new ExceptionEx4();
		 ee.devesion(10, 2,"ajay");
	}


}
