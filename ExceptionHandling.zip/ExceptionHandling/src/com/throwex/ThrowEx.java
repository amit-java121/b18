package com.throwex;

public class ThrowEx {
	
	
	public String test(int marks) {
		String msg = "";
		
		if(marks == 0) {
			//System.out.println("you are failed::");
			//msg = "Wrong input please try with other value.";
			throw new IllegalArgumentException("Wrong input please try with other value.");
			
		}else if(marks < 30) {
			msg = "you are failed.";
			
		}
		else {
			msg = "you are passed::";
			//System.out.println("you are passed::");
		}
		
		return msg;
	}
	
	
	public static void main(String[] args) {
		ThrowEx te = new ThrowEx();
		try {
		 int marks = 0;
			String str = te.test(marks);
			//logic
			System.out.println(str);
		
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}

}
