package com.throwex;

public class CustomException {
	
	public String validateUser(String userId) throws UserNotFoundException {
		
		//
		
		if(userId.equalsIgnoreCase("AC7266272")) {
			return "authorized";
		}else {
			
			throw new UserNotFoundException(1001,"UserNotFound");
			
		}
		
		
	}

}
