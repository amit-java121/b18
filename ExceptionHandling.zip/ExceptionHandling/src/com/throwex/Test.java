package com.throwex;

public class Test {
	
	public void verifyUser() {
		
		CustomException ce = new CustomException();
		try {
		String msg = ce.validateUser("AC7266273");
		System.out.println(msg);
		
		}catch(UserNotFoundException unf) {
			System.out.println(unf.getErrorCode());
			System.out.println(unf.getErrorMessage());
		}
	}
	
	public static void main(String[] args) {
		Test test = new Test();
		test.verifyUser();
	}

}
