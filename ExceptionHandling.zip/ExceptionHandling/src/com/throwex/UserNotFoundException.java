package com.throwex;

public class UserNotFoundException extends Exception{
	

	private static final long serialVersionUID = 8102905521333668244L;
	
	private int errorCode;
	private String errorMessage;
	
	public UserNotFoundException(int errorCode, String errorMessage) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
	public int getErrorCode() {
		return errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	 
	 
	 

}
