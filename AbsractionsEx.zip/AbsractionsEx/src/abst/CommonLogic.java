package abst;

public abstract class CommonLogic {
	
	public abstract void logUserActivities(String msg);
	
	public boolean verifyUser(String userName,String password) {
		
		if(userName.equalsIgnoreCase("amit@gmail.com") && password.equalsIgnoreCase("amit123")) {
			return true;
		}else {
			return false;
		}
		
	}

}
