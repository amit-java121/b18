package abst;

public abstract class Test {
	
	public abstract void m1();
	
	public void m2() {
		System.out.println("m2 called:::");
	}

}
