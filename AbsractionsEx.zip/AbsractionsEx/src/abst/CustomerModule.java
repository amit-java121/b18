package abst;

public class CustomerModule extends CommonLogic{
	
	
	
	
	public void doPayment(int amount,long accountNumber) {
		//withdraw logic
		logUserActivities("you are inside doPayment method");
		if(accountNumber == 1999999191) {
			//System.out.println("withdraw asked amount:::"+amount);
			logUserActivities("you have successfully withdrawn money"+amount);
		}else {
			//System.out.println("insufficient balance::");
			logUserActivities("you dont have sufficient balance");
		}
		
	}

	@Override
	public void logUserActivities(String msg) {
		
		System.out.println("your message will be written in txt file:: "+msg);
		
	}
	
	public static void main(String[] args) {
		CustomerModule cm = new CustomerModule();
		boolean flag = cm.verifyUser("amit@gmail.com", "amit123");
		if(flag) {
			cm.doPayment(1000, 1999999191);
		}else {
			cm.logUserActivities("you are not authorized for this payment::");
			//System.out.println("you are not authorized for this payment::");
		}
	}



}
