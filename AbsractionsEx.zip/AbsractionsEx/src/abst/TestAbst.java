package abst;

public class TestAbst extends Test{

	@Override
	public void m1() {
		System.out.println("m1 called:::");
		
	}
	
	
	public static void main(String[] args) {
		TestAbst testAbst = new TestAbst();
		
		testAbst.m1();
		testAbst.m2();
	}

}
