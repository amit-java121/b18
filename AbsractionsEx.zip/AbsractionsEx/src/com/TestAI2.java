package com;

public class TestAI2 implements AI{

	@Override
	public int add(int a, int b) {
		
		return a+b;
	}

	@Override
	public void m1() {
		System.out.println("m1 called from class TestAI2");
		
	}
	

}
