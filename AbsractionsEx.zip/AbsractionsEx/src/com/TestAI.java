package com;

public class TestAI implements AI{

	@Override
	public int add(int a, int b) {
		int sum = a+b;
		return sum;
	}

	@Override
	public void m1() {
		System.out.println("m1 called");
		
	}


}
