package com;

public interface AI {
	
	public abstract int add(int a,int b);
	
	void m1();
}
