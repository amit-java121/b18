package com;

public class Test {
	
	public static void main(String[] args) {
		
		TestAI test = new TestAI();
		int sum = test.add(10, 20);
		System.out.println(sum);
		test.m1();
		
	}

}
