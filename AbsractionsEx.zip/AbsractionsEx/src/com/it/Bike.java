package com.it;

public class Bike implements Vehicle{

	@Override
	public int weels() {
		// TODO Auto-generated method stub
		return 2;
	}

	@Override
	public int engine(String modelNo) {
		// TODO Auto-generated method stub
		return 150;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "black";
	}

	@Override
	public int seats() {
		// TODO Auto-generated method stub
		return 2;
	}

}
