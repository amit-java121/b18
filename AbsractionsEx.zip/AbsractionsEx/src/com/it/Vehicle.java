package com.it;

public interface Vehicle {
	
	public int weels();
	
	public int engine(String modelNo);
	
	public String color();
	
	public int seats();
	

}
