package com.it;

public class Bus implements Vehicle{

	@Override
	public int weels() {
		// TODO Auto-generated method stub
		return 6;
	}

	@Override
	public int engine(String modelNo) {
		// TODO Auto-generated method stub
		return 3000;
	}

	@Override
	public String color() {
		
		return "yellow";
	}

	@Override
	public int seats() {
		// TODO Auto-generated method stub
		return 0;
	}

}
