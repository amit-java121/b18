package com.it;

public class Car implements Vehicle{

	@Override
	public int weels() {

		return 4;
	}

	@Override
	public int engine(String modelNo) {
		
		if(modelNo.equals("baleno")) {
			return 1200;
		}else if(modelNo.equals("creta")) {
			return 1400;
		}
		
		return 0;
	}

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "gray";
	}

	@Override
	public int seats() {
		// TODO Auto-generated method stub
		return 4;
	}

}
