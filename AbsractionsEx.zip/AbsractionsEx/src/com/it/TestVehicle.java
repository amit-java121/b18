package com.it;

public class TestVehicle {
	
	public static void main(String[] args) {
		
//		Car car = new Car();
//		int hp =car.engine("baleno");
//		System.out.println(hp);
		
		
		Bus bus = new Bus();
		int busHp= bus.engine("mahindra");
		System.out.println(busHp);
		
	}

}
