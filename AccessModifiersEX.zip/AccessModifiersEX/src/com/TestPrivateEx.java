package com;

public class TestPrivateEx {
	
	private int userId;
	
	
	private int calculate() {
	
		System.out.println("calculate method called");
		return 0;
	}
	
	public void test() {
	
	}
	
	public TestPrivateEx() {
		System.out.println("const:::");
	}
	
	
	
	public static void main(String[] args) {
		
		TestPrivateEx tpe = new TestPrivateEx();
		tpe.test();
		
		System.out.println(tpe.userId);
	}
	

}
