package com;

import it.A;

public class Test {
	
	public void m1() {
		TestPrivateEx tp = new TestPrivateEx();
		tp.test();
		//////
		A a = new A();
		
	}

}
