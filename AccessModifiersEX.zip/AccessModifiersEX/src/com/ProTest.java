package com;

import it.ProtectedEx;

public class ProTest extends ProtectedEx{
	
	public void m2() {
		test();
		
	}
	
	public static void main(String[] args) {
		ProTest pt = new ProTest();
		
	    //ProtectedEx pe = new ProtectedEx();
	}

}
