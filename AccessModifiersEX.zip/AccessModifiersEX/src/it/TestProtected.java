package it;

public class TestProtected {
	
	public void m1() {
		ProtectedEx pe = new ProtectedEx();
		pe.test();
	}

}
