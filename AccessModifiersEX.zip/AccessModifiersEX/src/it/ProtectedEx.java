package it;

public class ProtectedEx {
	protected int age =30;
	
	protected void test() {
		
	}
	
	protected ProtectedEx() {
		
	}

}
