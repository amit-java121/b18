package it;

public class B {
	
	public void test() {
		A a = new A();
		a.add();
	}

}
