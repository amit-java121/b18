package it;

public class A {
	
	int age =25;
	
	int add() {
		
		return 0;
	}
	
	public A(){
		System.out.println("const::");
	}

}
