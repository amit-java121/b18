package thisex;

public class B extends A {
	
	private int age = 20;

	public void m1() {
		
		System.out.println(this.age);
		System.out.println(super.name);
		super.m3();
		this.m2();
	}
	
	public void m2() {
		
	}
	
	public B(int age) {
		
	}
	
	public B() {
		super();
		//this(10);
	}
	
	
}
