package thisex;

public class A {
	
	String name ="ajay";
	
	public void m3() {
		
	}
	
	
	public void m4() {
		
	}
	
	public A() {
		
	}

	public A(int id) {
		
	}
}
