package sets;

import java.util.NavigableSet;
import java.util.TreeSet;

public class TreeSetEx {
	
	public static void main(String[] args) {
		TreeSet<String> treeset = new TreeSet<>();
		treeset.add("sanjay");
		treeset.add("bijay");
		treeset.add("vijay");
		treeset.add("ajay");
		//treeset.add(null);
		
		System.out.println(treeset);
		
		NavigableSet<String> reverseElements = treeset.descendingSet();
		System.out.println(reverseElements);
		
	}

}
