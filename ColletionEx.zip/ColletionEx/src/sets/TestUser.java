package sets;

import java.util.HashSet;

public class TestUser {
	
	public void setValues() {
		HashSet<User> hashSet = new HashSet<User>();
		
		User user = new User();
		user.setUserId(100);
		user.setUserName("ajay");
		
		User user2 = new User();
		user2.setUserId(100);
		user2.setUserName("ajay");
		
		User user3 = new User();
		user3.setUserId(101);
		user3.setUserName("bjay");
		
		hashSet.add(user);
		hashSet.add(user2);
		hashSet.add(user3);
		
		System.out.println(hashSet.size());
		System.out.println(hashSet);
		
	}
	
	public static void main(String[] args) {
		TestUser tu = new TestUser();
		tu.setValues();
	}

}
