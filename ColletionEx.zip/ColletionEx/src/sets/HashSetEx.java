package sets;

import java.util.HashSet;

public class HashSetEx {
	
	
	public void getSetValues(HashSet<String> usersName) {
		
		if(usersName != null && !usersName.isEmpty()) {
			usersName.remove("ajay");
		}
		
		
		//
	}
	
	
	public static void main(String[] args) {
		
//		HashSetEx hashSetEx = new HashSetEx();
//		
//		hashSetEx.getSetValues(null);
		
		
		HashSet<String> hashSet = new HashSet<>();
		hashSet.add("bijay");
		hashSet.add("sanjay");
		hashSet.add("sanjay");
		hashSet.add("ajay");
		
		
		System.out.println(hashSet.size());
		System.out.println(hashSet);
		

		
		System.out.println(hashSet.retainAll(hashSet));
		
		
	}

}
