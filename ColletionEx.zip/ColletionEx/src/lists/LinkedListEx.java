package lists;

import java.util.LinkedList;

public class LinkedListEx {
	
	public static void main(String[] args) {
		LinkedList<String> linkedList = new LinkedList<>();
		
	}

}
