package lists;

import java.util.ArrayList;

public class TestList {

	public void printList() {
		
		ArrayListEx arrayListEx = new ArrayListEx();
		ArrayList list = arrayListEx.getEmpList();
		
		System.out.println(list);
	}
	
	
	public static void main(String[] args) {
		TestList testList = new TestList();
		testList.printList();
	}
	
}
