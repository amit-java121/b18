package lists;

import java.util.ArrayList;

public class EmployeeTest {
	
	public ArrayList<Employee> prepareEmpData() {
		ArrayList<Employee> empList = new ArrayList<Employee>();
		
		Employee emp = new Employee();
		emp.setEmpId(1000);
		emp.setEmpName("Ajay");
		emp.setCityName("pune");
		emp.setContactNumber(10817717771l);
		
		Employee emp2 = new Employee();
		emp2.setEmpId(1000);
		emp2.setEmpName("Bijay");
		emp2.setCityName("nagpur");
		emp2.setContactNumber(10817717771l);
		
		
		Employee emp3 = new Employee();
		emp3.setEmpId(1000);
		emp3.setEmpName("Deepak");
		emp3.setCityName("mumbai");
		emp3.setContactNumber(10817717771l);
		
		
		empList.add(emp);
		empList.add(emp2);
		empList.add(emp3);
		
		return empList;
	}
	
	public void printListData() {
		ArrayList<Employee> emplList = prepareEmpData();
		
		for(Employee emp:emplList) {
		
			//System.out.println(emp);
			
			System.out.println(emp.getEmpId());
			System.out.println(emp.getEmpName());
			System.out.println(emp.getCityName());
			System.out.println(emp.getContactNumber());
		}
	}
	
	public static void main(String[] args) {
		EmployeeTest et = new EmployeeTest();
		et.printListData();
	}

}
