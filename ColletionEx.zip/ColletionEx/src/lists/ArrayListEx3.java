package lists;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListEx3 {
	
	public static void main(String[] args) {
		
		ArrayList<String> list1 = new ArrayList<>();
		list1.add("ajay");
		list1.add("bijay");
		list1.add("sanjay");
		list1.add("abc");
		list1.add("xyz");
		
		ArrayList<String> list2 = new ArrayList<>();
		list2.add("abc");
		list2.add("xyz");
		
		//list1.addAll(list2);
		//list1.addAll(0, list2);
		//list1.clear();
		
		
		//System.out.println(list1.contains("bijay1"));
		
		//System.out.println(list1.indexOf("sanjay"));
		//System.out.println(list1.isEmpty());
		
		//System.out.println(list1.remove(0));
		//System.out.println(list1.remove("bijay"));
		//System.out.println(list1);
		//System.out.println(list1.removeAll(list2));
		
		
		//System.out.println(list1.retainAll(list2));
		//System.out.println(list1);
		
//		  Iterator<String> itr = list1.iterator();
//		  while(itr.hasNext()) {
//			  System.out.println(itr.next());
//		  }
		
		//List<String> subList = list1.subList(2, 5);
		//System.out.println(subList);
		
		System.out.println(list1.containsAll(list2));
	}

}
