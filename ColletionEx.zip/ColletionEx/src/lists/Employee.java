package lists;

public class Employee {
	private int empId;
	private String empName;
	private String cityName;
	private long contactNumber;
	
	public int getEmpId() {
		return empId;
	}
	public String getEmpName() {
		return empName;
	}
	public String getCityName() {
		return cityName;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", cityName=" + cityName + ", contactNumber="
				+ contactNumber + "]";
	}
	
	
	
	

}
