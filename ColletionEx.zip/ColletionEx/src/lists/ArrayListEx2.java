package lists;

import java.util.ArrayList;

public class ArrayListEx2 {
	
	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("ajay");
		list.add("bijay");
		//list.add(100);
		
		
		for(int i = 0;i<list.size(); i++) {
			
			String name = (String)list.get(i);
			
			System.out.println(name);
		}
		
	}

}
