package lists;

import java.util.ArrayList;
import java.util.Vector;

public class VectorEx {
	
	public static void main(String[] args) {
		
		Vector<String> vector = new Vector<>();
		//ArrayList<String> arrayList = new ArrayList<String>();
		vector.addElement("ajay");
		vector.addElement("bijay");
		vector.addElement("ajay");
		vector.addElement("sanjay");
		
		vector.addElement("ajay");
		vector.addElement("bijay");
		vector.addElement("ajay");
		vector.addElement("sanjay");
		vector.addElement("ajay");
		vector.addElement("bijay");
		vector.addElement("bijay");
		

		
		System.out.println(vector.size());
		
		System.out.println(vector.elementAt(1));
		System.out.println(vector.lastElement());
		
	   System.out.println(vector.removeElement("bijay"));
	   
		
	}

}
