package lists;

import java.util.ArrayList;

public class ArrayListEx {
	
	
	public ArrayList getEmpList() {
		
		ArrayList list = new ArrayList<>();
		
		list.add("Ajay");
		list.add("xpertit");
		list.add("deepak");
		list.add("vijay");
		
		return list;
		
	}
	
}
