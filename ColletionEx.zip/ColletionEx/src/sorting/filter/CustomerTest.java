package sorting.filter;

import java.util.ArrayList;
import java.util.List;

public class CustomerTest {
	
	public List<Customer>  prepareData() {
		
		Customer customer = new Customer();
		customer.setCustomerId(1000);
		customer.setCustomerAge(25);
		customer.setCustomerName("ajay");
		customer.setCustomerCityName("pune");
		
		Customer customer2 = new Customer();
		customer2.setCustomerId(1004);
		customer2.setCustomerAge(27);
		customer2.setCustomerName("sanjay");
		customer2.setCustomerCityName("mumbai");
		
		
		Customer customer3 = new Customer();
		customer3.setCustomerId(1002);
		customer3.setCustomerAge(30);
		customer3.setCustomerName("bijay");
		customer3.setCustomerCityName("nagpur");
		
		Customer customer4 = new Customer();
		customer4.setCustomerId(1005);
		customer4.setCustomerAge(30);
		customer4.setCustomerName("bijay");
		customer4.setCustomerCityName("pune");
		
		
		List<Customer> listOfCustomer = new ArrayList<Customer>();
		listOfCustomer.add(customer);
		listOfCustomer.add(customer2);
		listOfCustomer.add(customer3);
		listOfCustomer.add(customer4);
		
		return listOfCustomer;
		
	}
	
	public List<Customer> filterUserDataByCityName() {
		List<Customer> customerList = prepareData();
		List<Customer> filteredCustomerList = new ArrayList<>();
		
		for(Customer customer:customerList) {
			
			if(customer.getCustomerCityName().equalsIgnoreCase("pune")) {
				
				filteredCustomerList.add(customer);
			}
			
		}
		
		return filteredCustomerList;
	}
	
	public static void main(String[] args) {
		CustomerTest ct = new CustomerTest();
		List<Customer> customerList = ct.filterUserDataByCityName();
		System.out.println("customer list : "+customerList.toString());
	}

}
