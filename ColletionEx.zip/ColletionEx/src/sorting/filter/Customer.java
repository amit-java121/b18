package sorting.filter;

public class Customer {

	private int customerId;
	private String customerName;
	private int customerAge;
	private String customerCityName;
	public int getCustomerId() {
		return customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public int getCustomerAge() {
		return customerAge;
	}
	public String getCustomerCityName() {
		return customerCityName;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}
	public void setCustomerCityName(String customerCityName) {
		this.customerCityName = customerCityName;
	}
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAge=" + customerAge
				+ ", customerCityName=" + customerCityName + "]";
	}
	
	
	
}
