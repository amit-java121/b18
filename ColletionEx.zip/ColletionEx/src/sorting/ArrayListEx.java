package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListEx {
	
	public static void main(String[] args) {
		
		List<String> list = new ArrayList<>();
		
		list.add("sanjay");
		list.add("bijay");
		list.add("sanjay");
		list.add("ajay");
		list.add("abc");
		
		System.out.println(list);
		
		Collections.sort(list);
		
		System.out.println(list);
	}

}
