package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomerTest {
	
	public void prepareData() {
		
		Customer customer = new Customer();
		customer.setCustomerId(1000);
		customer.setCustomerAge(25);
		customer.setCustomerName("ajay");
		customer.setCustomerAddress("pune");
		
		Customer customer2 = new Customer();
		customer2.setCustomerId(1004);
		customer2.setCustomerAge(27);
		customer2.setCustomerName("sanjay");
		customer2.setCustomerAddress("mumbai");
		
		
		Customer customer3 = new Customer();
		customer3.setCustomerId(1002);
		customer3.setCustomerAge(30);
		customer3.setCustomerName("bijay");
		customer3.setCustomerAddress("nagpur");
		
		
		List<Customer> listOfCustomer = new ArrayList<Customer>();
		listOfCustomer.add(customer);
		listOfCustomer.add(customer2);
		listOfCustomer.add(customer3);
		
		
		Collections.sort(listOfCustomer);
		
		System.out.println(listOfCustomer.toString());
		
	}
	
	public static void main(String[] args) {
		CustomerTest ct = new CustomerTest();
		ct.prepareData();
	}

}
