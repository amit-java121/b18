package sorting.multi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class UserTest {
	
	public void prepareUserData() {
		
		User user = new User();
		user.setUserId(101);
		user.setUserAge(25);
		user.setUserName("sanjay");
		user.setAddress("pune");
		
		User user2 = new User();
		user2.setUserId(102);
		user2.setUserAge(26);
		user2.setUserName("ajay");
		user2.setAddress("pune");
		
		User user3 = new User();
		user3.setUserId(100);
		user3.setUserAge(28);
		user3.setUserName("bijay");
		user3.setAddress("mumbai");
		
		List<User> userList = new ArrayList<>();
		userList.add(user);
		userList.add(user2);
		userList.add(user3);
		
		
		Collections.sort(userList, new UserIdComparator());
		
		System.out.println("sorted on id: "+userList.toString());
		
		
		Collections.sort(userList, new UserNameComparator());
		
		System.out.println("sorted on name: "+userList);
		
	}
	
	public static void main(String[] args) {
		UserTest ut = new UserTest();
		ut.prepareUserData();
	}

}
