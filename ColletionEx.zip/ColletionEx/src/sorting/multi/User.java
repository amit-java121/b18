package sorting.multi;

public class User {
	private int userId;
	private String userName;
	private String address;
	private int userAge;
	public int getUserId() {
		return userId;
	}
	public String getUserName() {
		return userName;
	}
	public String getAddress() {
		return address;
	}
	public int getUserAge() {
		return userAge;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public void setUserAge(int userAge) {
		this.userAge = userAge;
	}
	
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", address=" + address + ", userAge=" + userAge
				+ "]";
	}
	
	

}
