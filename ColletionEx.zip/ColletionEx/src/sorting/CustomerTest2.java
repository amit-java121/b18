package sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CustomerTest2 {
	
	public void prepareData() {
		
		Customer2 customer = new Customer2();
		customer.setCustomerId(1000);
		customer.setCustomerAge(25);
		customer.setCustomerName("ajay");
		customer.setCustomerAddress("pune");
		
		Customer2 customer2 = new Customer2();
		customer2.setCustomerId(1004);
		customer2.setCustomerAge(27);
		customer2.setCustomerName("sanjay");
		customer2.setCustomerAddress("mumbai");
		
		
		Customer2 customer3 = new Customer2();
		customer3.setCustomerId(1005);
		customer3.setCustomerAge(30);
		customer3.setCustomerName("bijay");
		customer3.setCustomerAddress("nagpur");
		
		
		List<Customer2> listOfCustomer = new ArrayList<Customer2>();
		listOfCustomer.add(customer);
		listOfCustomer.add(customer2);
		listOfCustomer.add(customer3);
		
		
		Collections.sort(listOfCustomer);
		
		System.out.println(listOfCustomer.toString());
		
	}
	
	public static void main(String[] args) {
		CustomerTest2 ct = new CustomerTest2();
		ct.prepareData();
	}

}
