package sorting;

public class Customer implements Comparable<Customer>{
	private int customerId;
	private String customerName;
	private int customerAge;
	private String customerAddress;
	
	public int getCustomerId() {
		return customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public int getCustomerAge() {
		return customerAge;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	
	
	@Override
	public int compareTo(Customer o) {

		if(o.getCustomerId() == customerId) {
			return 0;
		}else if(o.getCustomerId() < customerId) {
			return 1;
		}else {
			return -1;
		}
		
	}
	
	
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerAge=" + customerAge
				+ ", customerAddress=" + customerAddress + "]";
	}

}
