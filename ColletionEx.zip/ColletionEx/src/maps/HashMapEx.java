package maps;

import java.util.HashMap;

public class HashMapEx {
	
	public static void main(String[] args) {
		
		HashMap<Integer, String> hashMap = new HashMap<>();
		
		hashMap.put(100, "ajay");
		hashMap.put(101, "bjay");
		hashMap.put(103, "vijay");
		hashMap.put(100, "sanjay");
		hashMap.put(null, null);
		hashMap.put(104, null);
		
		//System.out.println(hashMap.containsKey(104));
		
		//System.out.println(hashMap.get(101));
		
		//System.out.println(hashMap.getOrDefault(101, "test"));
		System.out.println(hashMap.putIfAbsent(101, "test"));
		
		System.out.println(hashMap);
		
	}

}
