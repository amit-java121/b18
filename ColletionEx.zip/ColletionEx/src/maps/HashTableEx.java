package maps;

import java.util.Hashtable;

public class HashTableEx {
	
	public static void main(String[] args) {
		
		
		
		
		Hashtable<Integer, String> hashTable = new Hashtable<>();
		hashTable.put(1001, "abc");
		hashTable.put(1003, "abc1");
		hashTable.put(1004, "abc2");
		hashTable.put(1002, "abc3");
		
		hashTable.put(1006, null);
		
		System.out.println(hashTable);
		
	}

}
