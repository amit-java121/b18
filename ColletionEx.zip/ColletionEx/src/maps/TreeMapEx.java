package maps;

import java.util.TreeMap;

public class TreeMapEx {
	
	public static void main(String[] args) {
		
//		TreeMap<Integer, String> treeMap = new TreeMap<>();
//		treeMap.put(100, "ajay");
//		treeMap.put(104, "sanjay");
//		treeMap.put(102, "bijay");
//		treeMap.put(101, "ajay");
//		treeMap.put(105, null);
//		
//		System.out.println(treeMap);
		
		
		TreeMap<String, String> treeMap1 = new TreeMap<>();
		treeMap1.put("a", "ajay");
		treeMap1.put("abc", "sanjay");
		treeMap1.put("ab", "bijay");
		treeMap1.put("b", "ajay");
		
//		System.out.println(treeMap1);
//		
//		System.out.println(treeMap1.keySet());
//		System.out.println(treeMap1.values());
		
		System.out.println(treeMap1.remove("abc"));
		System.out.println(treeMap1);
		
	}

}
