package maps;

import java.util.HashMap;
import java.util.Map.Entry;

public class EmployeeTest {
	
	public static HashMap<Integer, Employee> setValues() {
		
		Employee employee = new Employee();
		employee.setEmpId(1001);
		employee.setEmpName("Ajay");
		employee.setEmpCity("pune");
		
		Employee employee2 = new Employee();
		employee2.setEmpId(1002);
		employee2.setEmpName("Bjay");
		employee2.setEmpCity("pune");
		
		Employee employee3 = new Employee();
		employee3.setEmpId(1003);
		employee3.setEmpName("Sanjay");
		employee3.setEmpCity("pune");
		
		
		HashMap<Integer, Employee>  empMap = new HashMap<>();
		
		empMap.put(employee.getEmpId(), employee);
		
		empMap.put(employee2.getEmpId(), employee2);
		empMap.put(employee3.getEmpId(), employee3);
		
		return empMap;
		
	}
	
	
	public static void readMap() {
		
		HashMap<Integer, Employee> empMap = setValues();
		
//		for( Entry<Integer, Employee> map:empMap.entrySet()) {
//			System.out.println("key "+map.getKey()+" value "+map.getValue());
//		}
		
		Employee employeeData = empMap.get(1003);
		
		System.out.println(employeeData.toString());
		
	}
	
	public static void main(String[] args) {
		readMap();
	}

}
