package com;

public class TestUser {
	
	public User getUserData() {
		User user = new User(100,111111111l,"Test User","pune");
		return user;
	}
	
	public static void main(String[] args) {
		TestUser tu = new TestUser();
		User userObject = tu.getUserData();
		
		System.out.println(userObject.toString());
	}

}
