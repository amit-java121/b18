package com;

public class User {
	private int userID;
	private final long panNumber;
	private String userName;
	private String address;
	
	public User(int userID, long panNumber, String userName, String address) {
		super();
		this.userID = userID;
		this.panNumber = panNumber;
		this.userName = userName;
		this.address = address;
	}

	public int getUserID() {
		return userID;
	}

	public long getPanNumber() {
		return panNumber;
	}

	public String getUserName() {
		return userName;
	}

	public String getAddress() {
		return address;
	}

	@Override
	public String toString() {
		return "User [userID=" + userID + ", panNumber=" + panNumber + ", userName=" + userName + ", address=" + address
				+ "]";
	}
	

}
