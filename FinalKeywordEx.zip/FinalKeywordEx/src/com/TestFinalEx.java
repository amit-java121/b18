package com;

public class TestFinalEx extends Test{
	
	public void m1() {
		System.out.println("m1 called::");
	}

}
