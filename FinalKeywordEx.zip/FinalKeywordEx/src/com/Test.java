package com;

public class Test {
	String name;
	final int adhaarNumber;
	
	public Test() {
		adhaarNumber = 12121212;
	}
	
	public  void m1() {
		System.out.println("m1 called::");
		
		System.out.println(adhaarNumber);
	}
	
	public static void main(String[] args) {
		Test test = new Test();
		test.m1();
	}

}
