package com;

public class Job extends Thread{
	
	@Override
	public void run() {
		System.out.println("job thread "+Thread.currentThread().getName());
		for(int i =20; i<30; i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("i= "+i);
		}
	}
	
	

}
