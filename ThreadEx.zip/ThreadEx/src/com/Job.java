package com;

public class Job extends Thread{
	
	@Override
	public void run() {
		//write job code
		System.out.println("hello i am from thread::");
	}
	
	

}
