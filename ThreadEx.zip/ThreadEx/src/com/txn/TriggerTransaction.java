package com.txn;

public class TriggerTransaction {

	public static void main(String[] args) {
		
		Transaction tr = new Transaction();
		tr.start();
		
		Transaction tr2 = new Transaction();
		tr2.start();
		
		
	}
}
