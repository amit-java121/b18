package com.txn;

public class Task2 extends Thread{
	
	PrintNumber pn;
	
	public Task2(PrintNumber pn) {
		this.pn= pn;
	}
	@Override
	public void run() {
		pn.print();
		
	}

}
