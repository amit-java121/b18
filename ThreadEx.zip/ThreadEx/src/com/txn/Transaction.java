package com.txn;

public class Transaction extends Thread{
	
	static int balance = 1000;

	@Override
	public void run() {
		System.out.println("run method called::");
		for(int i= 0; i<=20; i++) {
			withdraw(200);
		}
		
	}
	
	private static synchronized void withdraw(int amt) {
		//write logic to withdraw money:::
	
		System.out.println("Thread "+Thread.currentThread().getName());
		if(balance > amt) {
			balance = balance-amt;
			System.out.println("available amoutn: "+balance);
		}else {
			System.out.println("not sufficient balance::");
		}
		
		
		
	}
}
