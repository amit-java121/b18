package com.txn;

public class Task1 extends Thread{
	
	PrintNumber pn;
	
	public Task1(PrintNumber pn) {
		this.pn = pn;
	}
	
	@Override
	public void run() {
		pn.print();
		
	}

}
