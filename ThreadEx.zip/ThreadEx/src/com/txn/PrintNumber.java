package com.txn;

public class PrintNumber {
	
	public void print() {
		
		System.out.println("number 1");
		System.out.println("number 2");
		System.out.println("number 3");
		System.out.println("number 4");
		System.out.println("number 5");
		System.out.println("number 6");
		
		synchronized (this) {
			
			for(int i=0; i<=5; i++) {
				System.out.println("i= "+i);
			}
		}
		
		
		System.out.println("number 7");
		System.out.println("number 8");
		System.out.println("number 9");
		
	}

}
