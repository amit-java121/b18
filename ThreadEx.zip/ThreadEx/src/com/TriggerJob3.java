package com;

public class TriggerJob3 {
	
	public static void main(String[] args) {
		Job3 job3 = new Job3();
		Thread th = new Thread(job3);
		th.start();
		
	}

}
