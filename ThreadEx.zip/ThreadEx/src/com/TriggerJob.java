package com;

public class TriggerJob {
	
	public static void main(String[] args) {
		
		Job job = new Job();
		job.start();
		
	}

}
