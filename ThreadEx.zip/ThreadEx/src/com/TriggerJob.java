package com;

public class TriggerJob {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.out.println("thread "+Thread.currentThread().getName());
//		for(int i =10; i<20; i++) {
//			System.out.println("i= "+i);
//		}
		
		Job job = new Job();
		job.setName("HDFC Bank");
		job.start();
		job.join();
		
		Job2 job2 = new Job2();
		job2.setName("HDFC ATM");
		job2.start();
		
		
		System.out.println("After job thread "+Thread.currentThread().getName());
//		for(int i =30; i<40; i++) {
//			System.out.println("i= "+i);
//		}
		
	}

}
