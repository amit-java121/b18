package method;

public class ExecuteProcess {
	
	public static void main(String[] args) {
		
		Process p  =  new Process();
		
		Thread th =  new Thread( new Runnable() {
			
			@Override
			public void run() {
				try {
					p.test();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		
		th.start();
		
		
		Thread th2 =  new Thread( new Runnable() {
			
			@Override
			public void run() {
					p.test2();
				
			}
		});
		
		th2.start();
		
	}

}
