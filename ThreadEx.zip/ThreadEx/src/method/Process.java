package method;

import java.util.Scanner;

public class Process {
	
	public void test() throws InterruptedException {
		System.out.println("started test method::");
		
		synchronized (this) {
			wait(5000);
		}
		//logic
		System.out.println("thread of test method resumed::::");
		
	}
	
	public  void test2() {
		System.out.println("test2 method called:::");
//		
//		try {
//			Thread.sleep(5000);
//		} catch (InterruptedException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		Scanner sc = new java.util.Scanner(System.in);
		System.out.println("press any key");
		sc.nextLine();
		
//		synchronized (this) {
//			notify();
//		}
		
		System.out.println("notify called:::");
	}

}
