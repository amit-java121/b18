package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.it.model.User;
import com.it.service.IUserService;

@Controller
public class UserController {
	
	@Autowired
	IUserService userService;
	
	@GetMapping("/")
	public String loginPage() {
		System.out.println("loginPage called::");
		return "login";
	}
	
	@GetMapping("/login")
	public String login(@RequestParam("username") String userName,@RequestParam("password") String password,Model model) {
		System.out.println("login method called::username "+userName+" pass "+password);
		
		boolean flag = userService.verifyUserCredentials(userName, password);
		
		if(flag) {
			
			return "redirect:/getUserList";
			
		}
		model.addAttribute("message", "Your user name and password is incorrect. Please trya again!");
		return "login";
	}
	
	
	@GetMapping("/register")
	public ModelAndView registerPage() {
		
		ModelAndView model = new ModelAndView("signupForm","user", new User());
		
		return model;
	}
	
	@PostMapping("/save")
	public ModelAndView saveUserData(@ModelAttribute User user) {
		System.out.println("user form data "+user.toString());
		boolean flag = userService.saveUserDetails(user);
		if(flag) {
			ModelAndView model = new ModelAndView("login");
			model.addObject("message", "Your profile has been created successfully!");
			return model;
		}
		
		ModelAndView model = new ModelAndView("signupForm","user", user);
		model.addObject("message", "Due to some network issue your profile could not be saved successfully!");
		return model;
	}

	@GetMapping("/getUserList")
	public String getUserList(Model model) {
		
		List<User> listOfUsers = userService.getUserList();
		model.addAttribute("listOfUsers", listOfUsers);
		
		return "userList";
	}
	
	@GetMapping("/delete")
	public String deleteUserById(@RequestParam("userId") int id,Model model) {
		
		boolean flag = userService.deletUserById(id);
		 
		 List<User> listOfUsers = userService.getUserList();
		 model.addAttribute("listOfUsers", listOfUsers);

		 if(flag) {
			 model.addAttribute("message", "User record has been deleted!!");
		 }else {
			 model.addAttribute("message", "User record could not be deleted due to some issue!!");
		 }
		 return "userList";
	}
	
	@GetMapping("/update")
	public ModelAndView getUserById(@RequestParam("userId") int id) {
		
		User user = userService.getUserById(id);
		ModelAndView model = new ModelAndView("signupForm","user", user);
		
		return model;
	}
	
}
