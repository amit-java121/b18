package com.it.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.it.service.IUserService;

@Controller
public class UserController {
	
	@Autowired
	IUserService userService;
	
	@GetMapping("/")
	public String loginPage() {
		System.out.println("loginPage called::");
		return "login";
	}
	
	@GetMapping("/login")
	public void login(@RequestParam("username") String userName,@RequestParam("password") String password) {
		System.out.println("login method called::username "+userName+" pass "+password);
		
		userService.verifyUserCredentials(userName, password);
	}

	
}
