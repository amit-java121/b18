package com.it.model;

public class User {

}
