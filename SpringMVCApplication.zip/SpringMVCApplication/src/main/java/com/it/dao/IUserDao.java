package com.it.dao;

public interface IUserDao {

}
