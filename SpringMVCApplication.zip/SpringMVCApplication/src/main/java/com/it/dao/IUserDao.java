package com.it.dao;

public interface IUserDao {

	void getUserCrdentials(String userName);

}
