package com.it.dao;

import com.it.model.User;

public interface IUserDao {

	User getUserCrdentials(String userName);

	void saveUserData(User user);

}
