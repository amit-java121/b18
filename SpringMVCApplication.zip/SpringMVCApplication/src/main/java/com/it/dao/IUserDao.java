package com.it.dao;

import com.it.model.User;

public interface IUserDao {

	User getUserCrdentials(String userName);

	boolean saveUserData(User user);

}
