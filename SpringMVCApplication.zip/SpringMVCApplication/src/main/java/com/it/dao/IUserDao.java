package com.it.dao;

import java.util.List;

import com.it.model.User;

public interface IUserDao {

	User getUserCrdentials(String userName);

	boolean saveUserData(User user);

	List<User> getUserListFrmDb();

	boolean deleteUserById(int id);

	User getUserById(int id);

}
