package com.it.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;

import com.it.model.User;
@Repository
public class UserDaoImpl implements IUserDao{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public User getUserCrdentials(String userName) {
		
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where userEmail=?");
		    User user= (User)query.setParameter(0, userName).getSingleResult();
		    
		    System.out.println(user.toString());
		    
		return user;
	}

	@Override
	public boolean saveUserData(User user) {
		try {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Serializable id = session.save(user);
		tr.commit();
		System.out.println(id);
		return true;
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

	@Override
	public List<User> getUserListFrmDb() {
		Session session = sessionFactory.openSession();
		List<User> listOfUsers = session.createCriteria(User.class).list();
		
		return listOfUsers;
	}
	
	public boolean deleteUserById(int id) {
		
		Session session = sessionFactory.getCurrentSession();
		try {
		User user = session.get(User.class, id);
		session.delete(user);
		return true;
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		
	}

	@Override
	public User getUserById(int id) {

		Session session = sessionFactory.getCurrentSession();
		User user = session.get(User.class, id);
		return user;
	}

}
