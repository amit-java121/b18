package com.it.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.it.model.User;
@Repository
public class UserDaoImpl implements IUserDao{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public User getUserCrdentials(String userName) {
		
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where userEmail=?");
		    User user= (User)query.setParameter(0, userName).getSingleResult();
		    
		    System.out.println(user.toString());
		    
		return user;
	}

	@Override
	public void saveUserData(User user) {
		Session session = sessionFactory.getCurrentSession();
		session.save(user);
		
	}

}
