package com.it.dao;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Repository;

import com.it.model.User;
@Repository
public class UserDaoImpl implements IUserDao{
	
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public User getUserCrdentials(String userName) {
		
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where userEmail=?");
		    User user= (User)query.setParameter(0, userName).getSingleResult();
		    
		    System.out.println(user.toString());
		    
		return user;
	}

	@Override
	public boolean saveUserData(User user) {
		try {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Serializable id = session.save(user);
		tr.commit();
		System.out.println(id);
		return true;
		}catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

}
