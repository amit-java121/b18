package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.IUserDao;
import com.it.model.User;

@Service
@Transactional
public class UserServiceImpl implements IUserService{
	
	@Autowired
	IUserDao userDao;

	@Override
	public boolean verifyUserCredentials(String userName, String password) {
		System.out.println("service called::");
		
		User user= userDao.getUserCrdentials(userName);
		
		if(user != null && user.getUserEmail().equals(userName) && user.getUserPass().equals(password)) {
			return true;
		}
		return false;
	}

	@Override
	public boolean saveUserDetails(User user) {
		return userDao.saveUserData(user);
		
	}

	@Override
	public List<User> getUserList() {
		return userDao.getUserListFrmDb();
	}

	@Override
	public boolean deletUserById(int id) {
		
		return userDao.deleteUserById(id);
	}

	@Override
	public User getUserById(int id) {
		return userDao.getUserById(id);
	}

}
