package com.it.service;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements IUserService{

	@Override
	public boolean verifyUserCredentials(String userName, String password) {
		System.out.println("service called::");
		System.out.println(userName);
		System.out.println(password);
		return false;
	}

}
