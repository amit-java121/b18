package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.it.dao.IUserDao;

@Service
@Transactional
public class UserServiceImpl implements IUserService{
	
	@Autowired
	IUserDao userDao;

	@Override
	public boolean verifyUserCredentials(String userName, String password) {
		System.out.println("service called::");
		
		userDao.getUserCrdentials(userName);
		return false;
	}

}
