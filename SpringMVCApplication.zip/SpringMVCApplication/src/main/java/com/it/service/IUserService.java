package com.it.service;

public interface IUserService {
	
	public boolean verifyUserCredentials(String userName,String password);

}
