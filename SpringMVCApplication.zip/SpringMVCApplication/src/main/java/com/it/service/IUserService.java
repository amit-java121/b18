package com.it.service;

import com.it.model.User;

public interface IUserService {
	
	public boolean verifyUserCredentials(String userName,String password);

	public void saveUserDetails(User user);

}
