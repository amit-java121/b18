package com.it.service;

import java.util.List;

import com.it.model.User;

public interface IUserService {
	
	public boolean verifyUserCredentials(String userName,String password);

	public boolean saveUserDetails(User user);

	public List<User> getUserList();

}
