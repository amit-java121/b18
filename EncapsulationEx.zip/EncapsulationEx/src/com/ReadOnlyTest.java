package com;

public class ReadOnlyTest {
	
	public ReadOnlyEx userData() {
		
		ReadOnlyEx readOnlyEx = new ReadOnlyEx(1000,"deepak","pune","IBM");
		
		return readOnlyEx;
	}
	
	
	
	public static void main(String[] args) {
		
		ReadOnlyTest rt = new ReadOnlyTest();
		ReadOnlyEx readOnlyObj= rt.userData();
		
		System.out.println(readOnlyObj.getCompanyName());
		
	}

}
