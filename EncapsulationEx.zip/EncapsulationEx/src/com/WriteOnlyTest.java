package com;

public class WriteOnlyTest {
	
	public WriteOnlyEx testWriteOnly() {
		WriteOnlyEx writeOnlyEx = new WriteOnlyEx(1000, "deepak", "mumbai", "HCL");
		
		return writeOnlyEx;
	}
	
	
	public static void main(String[] args) {
		WriteOnlyTest wt = new WriteOnlyTest();
		WriteOnlyEx writeOnlyObj= wt.testWriteOnly();
		writeOnlyObj.setCompanyName("Accenture");
	}

}
