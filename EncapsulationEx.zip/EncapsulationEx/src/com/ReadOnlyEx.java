package com;

public class ReadOnlyEx {
	private int id;
	private String name;
	private String address;
	private String companyName;
	
	
	
	public ReadOnlyEx(int id, String name, String address, String companyName) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.companyName = companyName;
	}
	
	
	public int getId() {
		return id;
	}
//	public void setId(int id) {
//		this.id = id;
//	}
	public String getName() {
		return name;
	}
//	public void setName(String name) {
//		this.name = name;
//	}
	public String getAddress() {
		return address;
	}
//	public void setAddress(String address) {
//		this.address = address;
//	}
	public String getCompanyName() {
		return companyName;
	}
//	public void setCompanyName(String companyName) {
//		this.companyName = companyName;
//	}
	
	
	
	

}
