package com.it.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.it.model.User;
import com.it.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/login")
	public ResponseEntity<String> login(@RequestParam("username") String ueserName,@RequestParam("password") String userPass ) {
		
		boolean flag = userService.checkUserCredentials(ueserName,userPass);
		
		if(flag) {
			return new ResponseEntity<String>("You are looged in successfully!", HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Your user name/password is incorect please try again!", HttpStatus.UNAUTHORIZED);
	}
	
	@PostMapping("/save")
	public void saveUserData(@RequestBody User user) {
		System.out.println("user data:: "+user.toString());
		
		userService.saveUserData(user);
	}
	
	@GetMapping("/getAllUser")
	public ResponseEntity<List<User>> getAllUserData() {
		List<User> listOfUser = userService.getAllUsers();
		
		return  new ResponseEntity<List<User>>(listOfUser, HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteUser(@PathVariable("id") int id) {
		
		System.out.println("id "+id);
		boolean flag = userService.deleteUserById(id);
		if(flag) {
			return "User Deleted Successfully!!";
		}
		
		return "User could not deleted";
	}
	
	@PutMapping("/update")
	public void updateUserDetails(@RequestBody User user) {
		System.out.println("update "+user.toString());
		userService.updateUser(user);
		
	}

}
