package com.it.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.it.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{

	User getByUserEmail(String ueserName);

	@Modifying
	@Query("update User u set u.userName=:username,u.userEmail=:useremail,u.gender=:gender where u.id=:id")
	void updateUserData(@Param("id")int id,@Param("useremail") String useremail,@Param("username") String username,@Param("gender") String gender);

}
