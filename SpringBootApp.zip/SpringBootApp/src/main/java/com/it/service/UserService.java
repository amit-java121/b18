package com.it.service;

import java.util.List;

import com.it.model.User;

public interface UserService {

	boolean checkUserCredentials(String ueserName, String userPass);

	void saveUserData(User user);

	List<User> getAllUsers();

}
