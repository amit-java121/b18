package com.it.service;

import com.it.model.User;

public interface UserService {

	User checkUserCredentials(String ueserName, String userPass);

}
