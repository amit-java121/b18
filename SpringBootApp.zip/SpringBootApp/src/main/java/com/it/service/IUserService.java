package com.it.service;

import java.util.List;

import com.it.exception.UserNotFountException;
import com.it.model.User;

public interface IUserService {

	boolean verifyUserCredentials(String username, String password);

	void saveUserDetails(User user);

	List<User> getAllUserData();

	void deleteUserById(int userid) throws UserNotFountException;

}
