package com.it.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.UserRepository;
import com.it.model.User;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository repository;

	@Override
	public boolean checkUserCredentials(String ueserName, String userPass) {
		
		User user = repository.getByUserEmail(ueserName);
		
		if(user != null && user.getUserEmail().equals(ueserName) && user.getUserPass().equals(userPass)) {
			return true;
		}
		
		return false;
	}

	@Override
	public void saveUserData(User user) {

		repository.save(user);
		
	}

	@Override
	public List<User> getAllUsers() {
		List<User> listOfUsers = repository.findAll();
		
		return listOfUsers;
	}

}
