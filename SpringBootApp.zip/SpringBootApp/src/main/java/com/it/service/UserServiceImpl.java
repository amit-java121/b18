package com.it.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.it.dao.UserRepository;
import com.it.model.User;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserRepository repository;

	@Override
	public User checkUserCredentials(String ueserName, String userPass) {
		
		User user = repository.getByUserEmail(ueserName);
		System.out.println(user.toString());
		
		return user;
	}

}
