package agg;

public class EmployeeData {
	
	public Employee setEmpData() {
		
		Employee employee = new Employee();
		employee.setEmpId(101);
		employee.setEmpName("Bijay");
		employee.setAge(25);
		
		Address address = new Address();
		address.setFlatNo(201);
		address.setSocietyName("hadapsar");
		address.setCityName("pune");
		address.setCountryName("india");
		address.setStateName("MH");	
		address.setPincode(411013);
		
		employee.setAddress(address);
		
		return employee;
	}
	
	
	public void printEmpData() {
//		EmployeeData ed = new EmployeeData();
//		ed.setEmpData();
		Employee employee = setEmpData();
		
		System.out.println(employee.getEmpId());
		System.out.println(employee.getEmpName());
		//System.out.println(employee.getAddress());
		Address add = employee.getAddress();
		System.out.println(add.getFlatNo());
		System.out.println(add.getCityName());
		System.out.println(add.getSocietyName());
		
		
	}
	
	public static void main(String[] args) {
		EmployeeData ed = new EmployeeData();
		ed.printEmpData();
	}

}
