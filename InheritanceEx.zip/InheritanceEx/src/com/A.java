package com;

public class A {
	
	int a =200;
	
	public void m1() {
		System.out.println("m1 executed from class A");
	}

}
