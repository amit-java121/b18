package com.multi;

public class B extends A{
	
	int b =100;
	
	public void m2() {
		System.out.println("m2 called::");
	}

}
