package com.multi;

public class C extends B{
	
	int c =100;
	
	public void m3() {
		System.out.println("m3 called::");
	}
	
	public static void main(String[] args) {
//		C c = new C();
//		
		B b = new C();
		b.m2();
//		C c2 = (C)new B();
//		c2.m1();
		
//		A a = new B();
		C c = new C();
//		
//		c.m1();
//		c.m2();
//		c.m3();
	}

}
