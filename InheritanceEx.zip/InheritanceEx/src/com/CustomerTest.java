package com;

public class CustomerTest {
	
	public static void main(String[] args) {
		
		Customer customer = new Customer(100,1010010001l,"Test","Pune");
		
		Customer customer1 = new Customer(101,1010010002l,"Test2","mumbai");
		
		
		System.out.println(customer.customerName);
		System.out.println(customer.customerAddress);
		
	}

}
