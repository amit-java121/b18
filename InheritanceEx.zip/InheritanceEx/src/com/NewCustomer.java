package com;

public class NewCustomer extends Customer{
	long adhaarNumber;

	
	public NewCustomer(int customerId, long voterCardNumber, String customerName, String customerAddress,
			long adhaarNumber) {
		super(customerId, voterCardNumber, customerName, customerAddress);
		this.adhaarNumber = adhaarNumber;
	}
	
	

}
