package com;

public class B extends A{
	int b =200;
	
	public void m2() {
		System.out.println("m2 exeucted from class B");
	}
	
	
	public static void main(String[] args) {
		A a = new A();
		
		B b = new B();
		b.m1();
		b.m2();
	}

}
