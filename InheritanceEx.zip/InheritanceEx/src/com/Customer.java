package com;

public class Customer {
	
	int customerId ;
	long voterCardNumber;
	String customerName;
	String customerAddress;
	
	public Customer(int customerId, long voterCardNumber, String customerName, String customerAddress) {
		super();
		this.customerId = customerId;
		this.voterCardNumber = voterCardNumber;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
	}
	
	
	

}
