package com;

public class TestNewCustomer {
	
	public static void main(String[] args) {
		
		
		NewCustomer newCustomer = new NewCustomer(1000, 292929992l, "Deepak", "pune", 83838838838l);
		
	}

}
