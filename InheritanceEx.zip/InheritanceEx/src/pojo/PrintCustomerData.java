package pojo;

public class PrintCustomerData {
	
	public void printData() {
		PrepareDataForCustomer pdc = new PrepareDataForCustomer();
		Customer customer = pdc.setDataIntoCustomer();
		
//		System.out.println(customer.getCustomerId());
//		System.out.println(customer.getCustomerName());
//		System.out.println(customer.getAge());
//		System.out.println(customer.getFlatNo());
//		System.out.println(customer.getSocietyName());
//		System.out.println(customer.getStateName());
		
		System.out.println(customer.toString());
		
	}
	
	public static void main(String[] args) {
		PrintCustomerData pcd = new PrintCustomerData();
		pcd.printData();
	}

}
