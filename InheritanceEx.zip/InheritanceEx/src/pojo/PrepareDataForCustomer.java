package pojo;

public class PrepareDataForCustomer {
	
	public Customer setDataIntoCustomer() {
		
		Customer customer = new Customer();
		customer.setCustomerId(10000);
		customer.setCustomerName("Ajay");
		customer.setAge(25);
		customer.setCityName("pune");
		customer.setFlatNo("B 201");
		customer.setSocietyName("magarpatta");
		customer.setStateName("MH");
		
		return customer;
		
	}

}
