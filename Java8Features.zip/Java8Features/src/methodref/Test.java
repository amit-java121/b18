package methodref;


public class Test {
	
	
//	public static int addition(int a,int b) {
//		
//		return a+b;
//	}
	
	public int addition(int a,int b) {
		
		return a+b;
	}
	
	
	
	public void test() {
		Test t = new Test();
		IMethodRef mf = (a,b) -> a+b;
         int sum = mf.add(10, 10);
		System.out.println(sum);
		
		IMethodRef mf2 = t::addition;
		
		int result = mf2.add(20, 20);
		System.out.println(result);
		
	}
	
	
	
	public static void main(String[] args) {
		
		Test test = new Test();
		test.test();
	}

}
