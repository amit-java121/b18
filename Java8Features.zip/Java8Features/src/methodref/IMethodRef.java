package methodref;
@FunctionalInterface
public interface IMethodRef {
	
	public int add(int a,int b);

}
