package methodref;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProcessUserData {

	public Optional<List<String>> fetchUserDataFrmDB() {

		List<String> list = new ArrayList<>();

		try {

			//
			//int a = 10/0;
			//
			
			list.add("abc");

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("is empty "+list);
		//return Optional.ofNullable(list);
		return Optional.of(list);

	}

	public void filterUserData() {
		 Optional<List<String>> optionalList = fetchUserDataFrmDB();
		 
		// 

		 if(optionalList.isPresent() && !optionalList.isEmpty()) {
				List<String> userList = optionalList.get();

				if (userList.get(0).equals("abc")) {
					System.out.println("user exist");
				} 
		 
		 }else {
				System.out.println("user does not exist");
			}
	}

	public static void main(String[] args) {
		ProcessUserData pud = new ProcessUserData();
		pud.filterUserData();
	}

}
