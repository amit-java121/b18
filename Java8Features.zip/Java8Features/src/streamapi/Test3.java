package streamapi;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class Test3 {
	
	public static void main(String[] args) {
		
		List<Employee> empList = new ArrayList<>();
		Employee emp = new Employee();
		emp.setId(100);
		emp.setAddress("pune");
		emp.setName("bijay");
		emp.setSalary(10000l);
		
		Employee emp1 = new Employee();
		emp1.setId(101);
		emp1.setAddress("pune");
		emp1.setName("ajay");
		emp1.setSalary(20000l);
		
		Employee emp2 = new Employee();
		emp2.setId(102);
		emp2.setAddress("pune");
		emp2.setName("sanjay");
		emp2.setSalary(50000l);
		
		empList.add(emp);
		empList.add(emp1);
		empList.add(emp2);
		
		
		//empList.stream().filter(x -> x.getId()> 100).forEach(System.out::println);
		
//		List<Employee> sortedList = empList.stream().sorted((a,b) -> b.getName().compareTo(a.getName())).collect(Collectors.toList());
//		System.out.println(sortedList);
		
		
		// Optional<Employee> mazSalary = empList.stream().max((a,b) -> b.getSalary().a.getSalary())));
		//System.out.println(mazSalary.get());
		
		Optional<Employee> maxSalary = empList.stream().max((a,b) -> a.getSalary().compareTo(b.getSalary()));
		System.out.println(maxSalary.get());
	}

}
