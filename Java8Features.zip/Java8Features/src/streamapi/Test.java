package streamapi;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Test {
	
	public static void main(String[] args) {
		
		List<Integer> list = Arrays.asList(1,10,3,4,5,6,7,8,9,2);
		
		list.stream().filter(number -> number%2==0).forEach(System.out::println);
		//list.parallelStream().filter(number -> number%2==0).forEach(number -> System.out.println(number+" "+Thread.currentThread().getName()));
		
		//list.parallelStream().filter(number -> number%2!=0).forEach(number -> System.out.println(number+" "+Thread.currentThread().getName()));
		
		//List<Integer> evenList = list.parallelStream().filter(number -> number%2==0).collect(Collectors.toList());
		//System.out.println(evenList);
		
		//list.stream().sorted().forEach(System.out::println);
		
		//List<Integer> newList = list.stream().map(number -> number*2).collect(Collectors.toList());
		//System.out.println(newList);
		
//		Optional<Integer> min = list.stream().min((a,b) -> a.compareTo(b));
//		System.out.println(min.get());
		
		//Optional<Integer> max = list.stream().max((a,b) -> a.compareTo(b));
		//System.out.println(max.get());
	}

}
