package com;

@FunctionalInterface
public interface IFunctionalInterface {
	
	public int calculate(int a ,int b);
	
	

}
