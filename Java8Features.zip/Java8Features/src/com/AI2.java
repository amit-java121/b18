package com;

public interface AI2 {
	
	void add();
	
	default int m1() {
		System.out.println("default method executed:::");
		return 100;
	}
	
	public static void m2() {
		System.out.println("static method executed:::");
	}

}
