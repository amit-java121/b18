package com;

public class TestAI2 implements AI2 {

	@Override
	public void add() {
		
		
	}
	
	public void test() {
		System.out.println("test executed:::");
		int i= m1();
		System.out.println(i);
		
		AI2.m2();
	}
	

}
