package com;

public class TestLambdaExpression {
	
	public void test() {
		
		IFunctionalInterface fi = (a,b) -> a+b;
		
		int result = fi.calculate(10, 20);
		System.out.println(result);
		
		IFunctionalInterface fi2 = (a,b) -> a*b;
		
		int result2 = fi2.calculate(10, 20);
		System.out.println(result2);
		
		
		
	}
	
	
	public void test2() {
		
		AI ai = (str1,str2) -> str1.equalsIgnoreCase(str2);
		
		System.out.println(ai.compare("abc", "Abc"));
	}
	
	public static void main(String[] args) {
		TestLambdaExpression tle = new TestLambdaExpression();
		//tle.test();
		tle.test2();
	}

}
