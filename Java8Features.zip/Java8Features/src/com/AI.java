package com;

@FunctionalInterface
public interface AI {
	
	public boolean compare(String str1,String str2);
	

}
