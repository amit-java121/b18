package loops;

public class TestForLoop {
	
	public void printData() {
		
		ForLoopEx fle = new ForLoopEx();
		
		int[] intArr = fle.prepareData();
		
		System.out.println(intArr[4]);
		
		for(int i=0; i<intArr.length; i++) {
			
			System.out.println(intArr[i]);
		}
		
//		for(Integer arr:intArr) {
//			System.out.println(arr);
//		}
		
	}
	
	public static void main(String[] args) {
		TestForLoop tfp = new TestForLoop();
		tfp.printData();
	}

}
