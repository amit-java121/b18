package loops;

public class ForLoopEx2 {
	
	public static void main(String[] args) {
		
		bb:
		for(int i=0; i<5; i++) {
			
			System.out.println("i = "+i);
			
			for(int j=0; j<2; j++ ) {
				
				if(i == 2) {
					break bb;
				}
				
				System.out.println("j "+j);

			}
//			if(i == 2) {
//			break;
//			}
		}
		
	}

}
