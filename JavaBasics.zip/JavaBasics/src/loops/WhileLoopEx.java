package loops;

public class WhileLoopEx {
	
	public static void main(String[] args) {
		
		//true//false
//		int a =10;
//		
//		while(a < 20) {
//			System.out.println("while loop executed:::"+a);
//			
//			a++;
//		}
		
		
		
		boolean flag = true;
		while(flag) {
			System.out.println("while loop executed:::");
			
			flag = false;
		}
		
	}

}
