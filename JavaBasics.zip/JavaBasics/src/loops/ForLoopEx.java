package loops;

public class ForLoopEx {

	
	public int[] prepareData() {
		
		int[] intArray = new int[5];
		intArray[0] = 10;
		intArray[1] = 20;
		intArray[2] = 30;
		intArray[3] = 40;
		intArray[4] = 50;
		//intArray[5] = 60;
		
		String[] strArray = new String[5];
		strArray[0] = "ajay";
		strArray[1] = "abc";
		strArray[2] = "";
		strArray[3] = "";
		strArray[4] = "";
		
		return intArray;
	}
	
}
