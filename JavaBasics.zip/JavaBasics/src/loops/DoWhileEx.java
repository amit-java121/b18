package loops;

public class DoWhileEx {
	
	public static void main(String[] args) {
		
		boolean flag =true;
		do {
			
			System.out.println("logic executed:::");
			//a++;
			boolean flag2 = m1();
			if(flag2) {
				System.out.println("inside if");
			}else {
				flag =false;
			}
			
			
		}while(flag);
		
	}
	
	
	public static boolean m1() {
		System.out.println("m1 executed:::");
		
		return false;
	}

}
