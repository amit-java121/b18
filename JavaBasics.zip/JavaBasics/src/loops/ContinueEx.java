package loops;

public class ContinueEx {
	
	public static void main(String[] args) {
		
		for(int i=0; i<5; i++) {
			
			System.out.println("i = "+i);
			
			if(i==2) {
				System.out.println("inside if::");
				continue;
			}
			
			System.out.println("after if condition:::");
			
		}
		
	}

}
