package com.methods;

public class TestString {
	
	public String compareValue(int age) {
		String msg = "";
		if(age < 18) {
			msg = "u r not eligible for vote";
			//System.out.println("u r not eligible for vote");
		}else {
			msg = "u r eligible for vote";
			//System.out.println("u r eligible for vote");
		}
		
		return msg;
	}
	
	public String compareValue2(int age) {
		if(age < 18) {
			return "u r not eligible for vote";
		}
		
		return "u r eligible for vote";
	}
	
	
	public static void main(String[] args) {
		TestString ts = new TestString();
		String msg = ts.compareValue2(10);
		System.out.println(msg);
		// age =18 or above
		// ur eligible for vote
		//u r not eligible for vote
	}

}
