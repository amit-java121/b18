package com.methods;

public class TestAB {

	public static void main(String[] args) {
		
		B b = new B();
		int finalResult = b.getSum(10,20,30);
		System.out.println(finalResult);
	}
	
}
