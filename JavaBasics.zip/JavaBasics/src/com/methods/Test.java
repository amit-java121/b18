package com.methods;

public class Test {
	
	public int add(int a,int b) {
		
		int sum = a+b;
		//System.out.println(sum);
		return sum;
	}
	
	public int multiply(int a,int b) {
		
		int num = 100;
		
		int summ = add(a,b);
		
		int multi = summ*num;
		
		return multi;
	}
	
	public static void main(String[] args) {
		Test test = new Test();
		int result = test.multiply(10, 20);
		System.out.println(result);
	}

}
