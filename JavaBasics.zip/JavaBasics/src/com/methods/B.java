package com.methods;

public class B {
	
	public int getSum(int x,int y,int z) {
		
		A a = new A();
		int sum = a.add(x,y,z);
		
		return sum;
	}

}
