package com;

public class Test2 {
	
	public void m1() {
		System.out.println("m1 called:::");
	}
	
	public void m2() {
		System.out.println("m2 called:::");
	}
	
	public static void main(String[] args) {
		System.out.println("hiiii....");
		
		Test2 test = new Test2();
		test.m1();
		
		test.m2();
		
	}

}
