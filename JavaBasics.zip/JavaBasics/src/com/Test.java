package com;

public class Test {
	
	public static void main(String[] args) {
		
		Duster d = new Duster();
		d.work();
		System.out.println(d.height);
	}

}
