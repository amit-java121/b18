package com.it;

public class A {
	
	int age = 30;//instance//global variable 
	static String name ="xpertit"; //static variable
	
	public void test() {
		int id = 100; //local variable
		
	}
	
	public void test2() {
		System.out.println(age);
		System.out.println(name);
	}
	
	public static void test3() {
		A a = new A();
		System.out.println(a.age);
		System.out.println(name);
	}
	
	public static void main(String[] args) {
		
		
		
//		int age = 25;
//		System.out.println(age);
//		  age = 30;
//		System.out.println(age);
//		
//		String name ="ajay";
//		System.out.println(name);
//		name = "abc";
//		System.out.println(name);
		
	}
	

}
