package com.it;

public class B {
	
	
	public void m1() {
		A a = new A();
		//System.out.println(A.name);
		System.out.println(a.age);
		a.test();
		
	}
	
	public static void main(String[] args) {
		B b = new B();
		b.m1();
		
	}
	
}
