package com.it;

public class B {
	
	int i;
	A a;
	
	public void m1() {
		
	}
	
}
