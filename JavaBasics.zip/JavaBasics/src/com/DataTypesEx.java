package com;

public class DataTypesEx {
	
	int a =1919919911;
	
	long l =9199199191991991991l;
	float f =10.10001f;
	double d = 10001.19199991d;
	char c = 'A';
	boolean flag = true;
//	short s = 19199;
//	byte b = 127;
	
	public static void main(String[] args) {
		
	
		String str ="xpert it";
		
		System.out.println(str);
		
		int[] intarray = new int[5];
		intarray[0] = 10;
		intarray[1] = 20;
		intarray[2] = 30;
		intarray[3] = 40;
		intarray[4] = 50;
		
		String[] strArray = new String[2];
		strArray[0] = "ajay";
		strArray[1] = "bijay";
		
		System.out.println(intarray[3]);
		System.out.println(strArray[1]);
		
	}

}
