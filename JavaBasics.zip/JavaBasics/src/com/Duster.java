package com;

public class Duster {
	int width =100;
	int length = 150;
	int height = 50;
	
	public void work() {
		System.out.println("cleaning....");
	}
	

}
