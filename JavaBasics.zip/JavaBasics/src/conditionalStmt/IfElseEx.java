package conditionalStmt;

public class IfElseEx {
	
	public void test(int age) {
		
		System.out.println("starting logic::");
		if(age > 25) {
			System.out.println(" u r eligiable for gov job");
		}else {
			System.out.println("u r not eligiable for gov job");
		}
		
		System.out.println("end logic::");
		
	}
	
	
	public static void main(String[] args) {
		IfElseEx ie = new IfElseEx();
		ie.test(20);
	}

}
