package conditionalStmt;

public class ElseIFex {
	
	public void test(int marks) {
		
		if(marks > 30 && marks <= 60) {
			System.out.println("u r passed"); 
		}else if(marks > 60 && marks <= 70) {
			System.out.println("u r passed with first devision");
		}else if(marks> 70 && marks <= 90) {
			System.out.println("u r passed with distinction");
		}else {
			System.out.println("u r failed");
		}
	}

	
	public static void main(String[] args) {
		ElseIFex ei = new ElseIFex();
		ei.test(20);
	}
}
