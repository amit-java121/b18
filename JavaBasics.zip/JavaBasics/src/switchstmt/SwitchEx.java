package switchstmt;

public class SwitchEx {
	
	public void test(int num) {
		
		switch (num) {
		case 10:
			System.out.println(" case 10 executed::");
			
			break;
		case 20:
			System.out.println(" case 20 executed::");
			
			break;
		case 30:
			System.out.println(" case 30 executed::");
			
			break;

		default:
			System.out.println("no case found ::");
			break;
		}
		
	}
	
	public static void main(String[] args) {
		SwitchEx se = new SwitchEx();
		se.test(30);
	}

}
