package switchstmt;

public class SwitchEx2 {
	
	// 
	public String dateFormat(String monthName) {
		String monthNumber = "";
		switch (monthName) {
		case "JAN":
			monthNumber= "01";
			break;
		case "FEB":
			monthNumber= "02";
			break;
		case "MAR":
			monthNumber= "03";	
			break;
		case "APR":
			monthNumber= "04";
			break;
			
		case "MAY":
			monthNumber= "05";
			break;
		default:
			break;
		}
		
		return monthNumber;
	}
	
	
	public static void main(String[] args) {
		
		String date = "20-FEB-2022";
		//29-03-2022
		String monthName = date.substring(3, 6);
		
		SwitchEx2 se2 = new SwitchEx2();
		String monthNumber =se2.dateFormat(monthName);
		System.out.println(monthNumber);
		
		String formattedDate = date.replace(monthName, monthNumber);
		
		System.out.println("formatted date : "+formattedDate);
	}

}
