package com;

public class Calculation3 {
	
	public void add(int a,long b) {
		System.out.println(a+b);
	}
	
	public void add(long a,int b) {
		System.out.println(a+b);
	}
	
	
	public static void main(String[] args) {
		Calculation3 cal3 = new  Calculation3();
		//cal3.add(10, 10); //Ambiguity issue
	}

}
