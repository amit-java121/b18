package com;

public class TestCalucation {
	
	public static void main(String[] args) {
		
		Calculation cal = new Calculation();
		int sum = cal.add(10, 10);
		System.out.println(sum);
	}

}
