package com.overriding;

public class A {
	
	public void test() {
		System.out.println("method called from class A");
	}
	
	public void getUser() {
		System.out.println("get user method called::");
	}

}
