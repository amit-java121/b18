package com.overriding;

public class B extends A{
	
	public void test() {
		//change the inner logic
		System.out.println("method called from class b");
	}
	
	public void test2() {
		System.out.println("test2 called:");
	}
	
	public static void main(String[] args) {
		B b = new B();
		b.test();
		b.getUser();
		
		A a = new B();
				
		a.test();
	}

}
