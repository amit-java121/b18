package com;

public class Calcalution2 {
	
	public int addition(int a,int b) {
		
		return a+b;
	}
	
	public long addition(long a,long b) {
		
		return a+b;
	}
	
	
	public void getUserDetails(int userId) {
		//logic to fetch data from DB using user id
	}
	
	public void getUserDetails(String userEmail) {
		//logic to fetch data from DB using user email	
	}
	
	

}
