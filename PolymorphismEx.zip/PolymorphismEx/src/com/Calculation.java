package com;

public class Calculation {

	public int add(int a,int b) {
		
		return a+b;
	}
	
	public int add(int a,int b,int c) {
		
		return a+b+c;
	}
	
	
}
