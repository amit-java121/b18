package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TestConnection {
	
	
	public void createJdbcConnection() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
			System.out.println("step 2");
			Statement stmt = con.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from customer");
			
			while(rs.next()) {
				
				System.out.println(rs.getInt("customer_id"));
				System.out.println(rs.getString("customer_name"));
				System.out.println(rs.getString("customer_email"));
				System.out.println(rs.getString("customer_pass"));
				System.out.println(rs.getString("gender"));
				System.out.println(rs.getString("country"));
				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
//	
//	public static void main(String[] args) {
//		TestConnection tc = new TestConnection();
//		tc.createJdbcConnection();
//	}
	
	
	public List<Customer> getAllCustomerData() {
		List<Customer> listOfCustomer = new ArrayList<>();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
			System.out.println("step 2");
			Statement stmt = con.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from customer");
			

			
			
			while(rs.next()) {
				Customer customer = new Customer();
				
				customer.setCustomerId(rs.getInt("customer_id"));
				customer.setCustomerName(rs.getString("customer_name"));
				customer.setCustomerPass(rs.getString("customer_pass"));
				customer.setCustomerEmail(rs.getString("customer_email"));
				customer.setGender(rs.getString("gender"));
				customer.setCountry(rs.getString("country"));
				
				listOfCustomer.add(customer);
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listOfCustomer;
		
	}
	
	public void saveCustomerData(Customer customer) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
			System.out.println("step 2");
			Statement stmt = con.createStatement();
			System.out.println("step 3");
			
			int number = stmt.executeUpdate("insert into customer (customer_name,customer_email,gender,country,customer_pass) values('"+customer.getCustomerName()+"','"+customer.getCustomerEmail()+"','"+customer.getGender()+"','"+customer.getCountry()+"','"+customer.getCustomerPass()+"') ");
			System.out.println(number);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	

}
