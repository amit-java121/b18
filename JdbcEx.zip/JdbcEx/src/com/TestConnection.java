package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestConnection {
	
	
	public void createJdbcConnection() {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("step 1");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
			System.out.println("step 2");
			Statement stmt = con.createStatement();
			System.out.println("step 3");
			ResultSet rs = stmt.executeQuery("select * from customer");
			
			while(rs.next()) {
				
				System.out.println(rs.getInt("customer_id"));
				System.out.println(rs.getString("customer_name"));
				System.out.println(rs.getString("customer_email"));
				System.out.println(rs.getString("customer_pass"));
				System.out.println(rs.getString("gender"));
				System.out.println(rs.getString("country"));
				
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		TestConnection tc = new TestConnection();
		tc.createJdbcConnection();
	}
	
	

}
