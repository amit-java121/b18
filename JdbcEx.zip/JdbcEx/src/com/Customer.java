package com;

public class Customer {
	
	private int customerId;
	private String customerName;
	private String customerEmail;
	private String customerPass;
	private String gender;
	private String country;
	public int getCustomerId() {
		return customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public String getCustomerPass() {
		return customerPass;
	}
	public String getGender() {
		return gender;
	}
	public String getCountry() {
		return country;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public void setCustomerPass(String customerPass) {
		this.customerPass = customerPass;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerEmail="
				+ customerEmail + ", customerPass=" + customerPass + ", gender=" + gender + ", country=" + country
				+ "]";
	}
	
	

}
