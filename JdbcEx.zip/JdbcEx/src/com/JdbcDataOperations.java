package com;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JdbcDataOperations {
	
	public void printCustomerData() {
		
		TestConnection tc = new TestConnection();
		List<Customer> listOfCustomer = tc.getAllCustomerData();
		System.out.println(listOfCustomer.toString());
	}
	
	
	public void insertCustomerData() {
		
		Customer customer = new Customer();
		customer.setCustomerName("bijay");
		customer.setCustomerPass("bijay123");
		customer.setCustomerEmail("bijat@gmail.com");
		customer.setCountry("india");
		customer.setGender("male");
		
		TestConnection tc = new TestConnection();
		tc.saveCustomerData(customer);
		
	}
	
	public void insertMultipleCustomer() {
		
		Customer customer = new Customer();
		customer.setCustomerName("bijay");
		customer.setCustomerPass("bijay123");
		customer.setCustomerEmail("bijat@gmail.com");
		customer.setCountry("india");
		customer.setGender("male");
		
		Customer customer2 = new Customer();
		customer2.setCustomerName("ajay");
		customer2.setCustomerPass("ajay123");
		customer2.setCustomerEmail("ajay@gmail.com");
		customer2.setCountry("india");
		customer2.setGender("male");
		
		Customer customer3 = new Customer();
		customer3.setCustomerName("sanjay");
		customer3.setCustomerPass("sanjay123");
		customer3.setCustomerEmail("sanjay@gmail.com");
		customer3.setCountry("india");
		customer3.setGender("male");
		
		ArrayList<Customer> listOfCustomer = new ArrayList<Customer>();
		listOfCustomer.add(customer);
		listOfCustomer.add(customer2);
		listOfCustomer.add(customer3);
		
		TestConnection tc = new TestConnection();
		
		tc.saveMultipleCustomerData(listOfCustomer);
		
	}
	
	
	public void deleteCustomerbyId() {
		
		TestConnection tc = new TestConnection();
		try {
			tc.deleteCustomerById(4);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	public void updateCustomerData() {
		Customer customer = new Customer();
		customer.setCustomerId(5);
		customer.setCustomerName("bijay123");
		customer.setCustomerEmail("bijay123@gmail.com");
		customer.setCountry("US");
		
		TestConnection tc = new TestConnection();
		tc.updateCustomer(customer);
	}
	
	public static void main(String[] args) {
		JdbcDataOperations jdo = new JdbcDataOperations();
		//jdo.printCustomerData();//record fetch
		//jdo.insertCustomerData();//record insert
		//jdo.insertMultipleCustomer();//multiple objects
		//jdo.deleteCustomerbyId();//delete customer
		jdo.updateCustomerData();
	}

}
