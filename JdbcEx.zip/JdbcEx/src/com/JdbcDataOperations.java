package com;

import java.util.List;

public class JdbcDataOperations {
	
	public void printCustomerData() {
		
		TestConnection tc = new TestConnection();
		List<Customer> listOfCustomer = tc.getAllCustomerData();
		System.out.println(listOfCustomer.toString());
	}
	
	
	public void insertCustomerData() {
		
		Customer customer = new Customer();
		customer.setCustomerName("bijay");
		customer.setCustomerPass("bijay123");
		customer.setCustomerEmail("bijat@gmail.com");
		customer.setCountry("india");
		customer.setGender("male");
		
		TestConnection tc = new TestConnection();
		tc.saveCustomerData(customer);
		
	}
	
	
	public static void main(String[] args) {
		JdbcDataOperations jdo = new JdbcDataOperations();
		//jdo.printCustomerData();//record fetch
		jdo.insertCustomerData();//record insert
	}

}
