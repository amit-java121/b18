package com.service;

import com.dao.DBConnection;

public class LoginService {

	public boolean verifyCustomer(String userName, String password) {
		System.out.println(userName+" "+password);
		
		DBConnection connection = new DBConnection();
		String dbPassword = connection.getCustomerCredentials(userName);
		
		if(dbPassword != null && dbPassword.equals(password)) {
			return true;
		}
		
		
		return false;
	}

}
