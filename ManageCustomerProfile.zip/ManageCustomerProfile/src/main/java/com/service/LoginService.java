package com.service;

import java.util.List;

import com.dao.DBConnection;
import com.model.Customer;

public class LoginService {

	public boolean verifyCustomer(String userName, String password) {
		System.out.println(userName+" "+password);
		
		DBConnection connection = new DBConnection();
		String dbPassword = connection.getCustomerCredentials(userName);
		
		if(dbPassword != null && dbPassword.equals(password)) {
			return true;
		}
		
		
		return false;
	}
	
	public boolean saveCustomerData(Customer customer) {
		
		DBConnection connection = new DBConnection();
		boolean flag = connection.saveCustomerDetails(customer);
		
		return flag;
		
		
	}

	public List<Customer> getAllCustomer() {
		DBConnection connection = new DBConnection();
		
		//List<Customer> listOfCustomers = connection.getAllCustomers();
		
		return connection.getAllCustomers(); 
		
	}

}
