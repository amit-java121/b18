package com.it;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Customer;
import com.service.LoginService;

/**
 * Servlet implementation class SaveController
 */
@WebServlet("/save")
public class SaveController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String customerName = request.getParameter("custName");
		String customerPassword = request.getParameter("password");
		String email = request.getParameter("custEmail");
		String gender = request.getParameter("gender");
		String country = request.getParameter("country");
		
		Customer customer = new Customer();
		customer.setCustomerName(customerName);
		customer.setCustomerPass(customerPassword);
		customer.setCustomerEmail(email);
		customer.setGender(gender);
		customer.setCountry(country);
		
		LoginService loginService = new LoginService();
		boolean flag = loginService.saveCustomerData(customer);
		

		if(flag) {
			request.setAttribute("message", "Customer profile has been created successfully. please try to login!!");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
			
		}else {
			System.out.println("user credentials is incorrect please try again::");
			request.setAttribute("message", "Customer is not saved successfully. please try again!!");
			RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
			rd.forward(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
