package com.it;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Customer;
import com.service.LoginService;

/**
 * Servlet implementation class UpdateConstroller
 */
@WebServlet("/update")
public class UpdateConstroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateConstroller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		String id = request.getParameter("customerId");
//		int idd = Integer.valueOf(id);
		String email = request.getParameter("custEmail");
		if(email == null) {
		int customerID = Integer.valueOf(request.getParameter("customerId"));
		
		LoginService loginService = new LoginService();
		Customer customer = loginService.getCustomerDataById(customerID);
		
		request.setAttribute("customer",customer);
		RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
		rd.forward(request, response);
		}else {
			int customerId = Integer.valueOf(request.getParameter("custId"));
			String customerName = request.getParameter("custName");
			String custEmail = request.getParameter("custEmail");
			String gender = request.getParameter("gender");
			String country = request.getParameter("country");
			
			
			Customer customer = new Customer();
			customer.setCustomerId(customerId);
			customer.setCustomerName(customerName);
			customer.setCustomerEmail(custEmail);
			customer.setGender(gender);
			customer.setCountry(country);
			
			LoginService loginService = new LoginService();
			loginService.updateCustomerData(customer);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
