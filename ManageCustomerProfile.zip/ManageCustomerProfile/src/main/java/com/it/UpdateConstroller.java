package com.it;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.Customer;
import com.service.LoginService;

/**
 * Servlet implementation class UpdateConstroller
 */
@WebServlet("/update")
public class UpdateConstroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateConstroller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
//		String id = request.getParameter("customerId");
//		int idd = Integer.valueOf(id);
		int customerId= 0;
		String email = request.getParameter("custEmail");
		if(email == null) {
		int customerID = Integer.valueOf(request.getParameter("customerId"));
		
		LoginService loginService = new LoginService();
		Customer customer = loginService.getCustomerDataById(customerID);
		
		request.setAttribute("customer",customer);
		RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
		rd.forward(request, response);
		}else {
			customerId = Integer.valueOf(request.getParameter("custId"));
			String customerName = request.getParameter("custName");
			String custEmail = request.getParameter("custEmail");
			String gender = request.getParameter("gender");
			String country = request.getParameter("country");
			
			
			Customer customer = new Customer();
			customer.setCustomerId(18);
			customer.setCustomerName(customerName);
			customer.setCustomerEmail(custEmail);
			customer.setGender(gender);
			customer.setCountry(country);
			
			LoginService loginService = new LoginService();
			boolean flag = loginService.updateCustomerData(customer);
			
			if(flag) {
				
				List<Customer> listOfCustomers = loginService.getAllCustomer();
				request.setAttribute("list",listOfCustomers);
				request.setAttribute("message", "Customer profile has been updated successfully.!!");
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
				
			}else {
				Customer customer1 = loginService.getCustomerDataById(customerId);
				request.setAttribute("customer",customer1);
				request.setAttribute("message", "Customer profile is not updated successfully.!!");
				RequestDispatcher rd = request.getRequestDispatcher("update.jsp");
				rd.forward(request, response);
				
			}
			
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
