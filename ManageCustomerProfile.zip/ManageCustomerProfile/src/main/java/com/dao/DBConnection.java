package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.model.Customer;

public class DBConnection {
	
	public String getCustomerCredentials(String userName) {
		String password = null;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
		
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select customer_pass from customer where customer_email='"+userName+"'");
		
		while(rs.next()) {
			 password = rs.getString("customer_pass");
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return password;
		
	}
	
	
	public boolean saveCustomerDetails(Customer customer) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
			PreparedStatement pstmt = conn.prepareStatement("insert into customer (customer_name,customer_email,gender,country,customer_pass) values(?,?,?,?,?)");
			pstmt.setString(1, customer.getCustomerName());
			pstmt.setString(2, customer.getCustomerEmail());
			pstmt.setString(3, customer.getGender());
			pstmt.setString(4, customer.getCountry());
			pstmt.setString(5, customer.getCustomerPass());
			
			int i = pstmt.executeUpdate();
			System.out.println("i "+i);
			
			if(i >0 ) {
				return true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return false;
	}


	public List<Customer> getAllCustomers() {
		List<Customer> listOfCustomers = new ArrayList<Customer>();
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
		PreparedStatement pstmt = conn.prepareStatement("select * from customer");
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next()) {
			Customer customer = new Customer();
			customer.setCustomerId(rs.getInt("customer_id"));
			customer.setCustomerName(rs.getString("customer_name"));
			customer.setCustomerEmail(rs.getString("customer_email"));
			customer.setGender(rs.getString("gender"));
			customer.setCountry(rs.getString("country"));
			customer.setCustomerPass(	rs.getString("customer_pass"));
			
			listOfCustomers.add(customer);
			
		}
		
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		
		return listOfCustomers;
	}


	public boolean deleteCustomer(int id) {
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
			PreparedStatement pstmt = conn.prepareStatement("delete from customer where customer_id=?");
			pstmt.setInt(1, id);
			
			int num = pstmt.executeUpdate();
			System.out.println(num);
			if(num > 0) {
				return true;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return false;
		
	}


	public Customer getCustomerDataById(int customerID) {
		 Customer customer = new Customer();
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
		PreparedStatement pstmt = conn.prepareStatement("select * from customer where customer_id=?");
		pstmt.setInt(1, customerID);
		 ResultSet rs = pstmt.executeQuery();
		 
		
		 while(rs.next()) {
			 
			customer.setCustomerId(rs.getInt("customer_id"));
			customer.setCustomerName(rs.getString("customer_name"));
			customer.setCustomerEmail(rs.getString("customer_email"));
			customer.setGender(rs.getString("gender"));
			customer.setCountry(rs.getString("country"));
			customer.setCustomerPass(rs.getString("customer_pass"));
			 
		 }
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return customer;
	}


	public void updateCustomerData(Customer customer) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
			PreparedStatement pstmt = conn.prepareStatement("update customer set customer_name=?,customer_email=?,gender=?,country=? where customer_id=?");
			pstmt.setString(1, customer.getCustomerName());
			pstmt.setString(2, customer.getCustomerEmail());
			pstmt.setString(3, customer.getGender());
			pstmt.setString(4, customer.getCountry());
			pstmt.setInt(5, customer.getCustomerId());
			
			int i = pstmt.executeUpdate();
			System.out.println("i "+i);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
