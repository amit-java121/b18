package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DBConnection {
	
	public String getCustomerCredentials(String userName) {
		String password = null;
		try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/b18","root","root");
		
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("select customer_pass from customer where customer_email='"+userName+"'");
		
		while(rs.next()) {
			 password = rs.getString("customer_pass");
		}
		
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return password;
		
	}

}
